 ## Requirements
 See requirements.txt

 ## How to reproduce the result:
 Under src path, run: 

	python prepare_data.py
	python hour_models.py 
	python day_models_with_hour.py 
	python day_models_no_hour.py 
	python hourly_sub.py
	python daily_sub.py

The generated submission file 'final_sub.csv' is under src folder.